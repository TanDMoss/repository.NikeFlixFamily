# resource.images.languageflags.colour
