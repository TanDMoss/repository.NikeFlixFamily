"""Skin Shortcuts library."""
