#!/usr/bin/python
# -*- coding: utf-8 -*-

'''
    script.skin.helper.service
    Helper service and scripts for Kodi skins
    Main service entry point
'''

from resources.lib.main_service import MainService
MainService()
