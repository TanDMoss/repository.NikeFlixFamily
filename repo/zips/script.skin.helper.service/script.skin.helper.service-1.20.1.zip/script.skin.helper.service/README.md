# script.skin.helper.service

[![Codacy Badge](https://api.codacy.com/project/badge/Grade/d253881b0e6a45a68a82dec8ee275d8f)](https://www.codacy.com/app/m-vanderveldt/script-skin-helper-service?utm_source=github.com&utm_medium=referral&utm_content=marcelveldt/script.skin.helper.service&utm_campaign=badger)

a helper service for Kodi skins

________________________________________________________________________________________________________

## Documentation
All documentation for this addon can be found in the online wiki:

https://github.com/kodi-community-addons/script.skin.helper.service/wiki


## Help needed with maintaining !
I am very busy currently so I do not have a lot of time to work on this project or watch the forums.
Be aware that this is a community driven project, so feel free to submit PR's yourself to improve the code and/or help others with support on the forums etc. If you're willing to really participate in the development, please contact me so I can give you write access to the repo. I do my best to maintain the project every once in a while, when I have some spare time left.
Thanks for understanding!

