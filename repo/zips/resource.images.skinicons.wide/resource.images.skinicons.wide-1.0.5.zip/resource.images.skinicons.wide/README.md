# resource.images.skinicons.wide
